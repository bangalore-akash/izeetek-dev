import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WarehouseAnalyticsComponent } from './pages/warehouse-analytics/warehouse-analytics.component';
import { WarehouseManagementComponent } from './pages/warehouse-management/warehouse-management.component';

const routes: Routes = [
  {
    path: '',
    component: WarehouseManagementComponent
  } ,
  {
    path: 'WarehouseManagement',
    component: WarehouseManagementComponent
  } ,
  {
    path: 'WarehouseAnalytics',
    component: WarehouseAnalyticsComponent
  },

  {
    path: '',
    redirectTo: '',
    pathMatch: 'full'
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ExpertiseRoutingModule { }
