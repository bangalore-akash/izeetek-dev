import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-implementtion-and-consulting',
  templateUrl: './implementtion-and-consulting.component.html',
  styleUrls: ['./implementtion-and-consulting.component.css']
})
export class ImplementtionAndConsultingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
