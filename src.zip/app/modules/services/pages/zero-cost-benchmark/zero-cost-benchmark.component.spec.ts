import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ZeroCostBenchmarkComponent } from './zero-cost-benchmark.component';

describe('ZeroCostBenchmarkComponent', () => {
  let component: ZeroCostBenchmarkComponent;
  let fixture: ComponentFixture<ZeroCostBenchmarkComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ZeroCostBenchmarkComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ZeroCostBenchmarkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
