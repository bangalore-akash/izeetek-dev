import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DevelopmentAndTechnicalIntegrationComponent } from './development-and-technical-integration.component';

describe('DevelopmentAndTechnicalIntegrationComponent', () => {
  let component: DevelopmentAndTechnicalIntegrationComponent;
  let fixture: ComponentFixture<DevelopmentAndTechnicalIntegrationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DevelopmentAndTechnicalIntegrationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DevelopmentAndTechnicalIntegrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
