import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ServicesRoutingModule } from './services-routing.module';
import { ZeroCostBenchmarkComponent } from './pages/zero-cost-benchmark/zero-cost-benchmark.component';
import { ImplementtionAndConsultingComponent } from './pages/implementtion-and-consulting/implementtion-and-consulting.component';

@NgModule({
  declarations: [ZeroCostBenchmarkComponent, ImplementtionAndConsultingComponent],
  imports: [
    CommonModule,
    ServicesRoutingModule
  ]
})
export class ServicesModule { }
