import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImplementtionAndConsultingComponent } from './implementtion-and-consulting.component';

describe('ImplementtionAndConsultingComponent', () => {
  let component: ImplementtionAndConsultingComponent;
  let fixture: ComponentFixture<ImplementtionAndConsultingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImplementtionAndConsultingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImplementtionAndConsultingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
