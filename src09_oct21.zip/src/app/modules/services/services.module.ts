import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ServicesRoutingModule } from './services-routing.module';
import { ZeroCostBenchmarkComponent } from './pages/zero-cost-benchmark/zero-cost-benchmark.component';
import { ImplementtionAndConsultingComponent } from './pages/implementtion-and-consulting/implementtion-and-consulting.component';
import { DevelopmentAndTechnicalIntegrationComponent } from './pages/development-and-technical-integration/development-and-technical-integration.component';
import { SupportComponent } from './pages/support/support.component';
import { StaffingSolutionsComponent } from './pages/staffing-solutions/staffing-solutions.component';

@NgModule({
  declarations: [ZeroCostBenchmarkComponent, ImplementtionAndConsultingComponent, DevelopmentAndTechnicalIntegrationComponent, SupportComponent, StaffingSolutionsComponent],
  imports: [
    CommonModule,
    ServicesRoutingModule
  ]
})
export class ServicesModule { }
