import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ExpertiseRoutingModule } from './expertise-routing.module';
import { WarehouseAnalyticsComponent } from './pages/warehouse-analytics/warehouse-analytics.component';
import { WarehouseManagementComponent } from './pages/warehouse-management/warehouse-management.component';

@NgModule({
  declarations: [WarehouseAnalyticsComponent, WarehouseManagementComponent],
  imports: [
    CommonModule,
    ExpertiseRoutingModule
  ]
})
export class ExpertiseModule { }
